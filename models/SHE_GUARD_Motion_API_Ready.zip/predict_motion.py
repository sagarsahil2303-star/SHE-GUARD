
import numpy as np
import joblib
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
model = joblib.load(BASE_DIR / "motion_model.pkl")

def predict_motion(readings):
    """
    readings: list of 200 rows, each containing 6 numeric channels.
    Channel order must match metadata.json.
    """
    data = np.asarray(readings, dtype=float)

    if data.shape != (200, 6):
        raise ValueError(
            "Expected exactly 200 readings x 6 channels."
        )

    if not np.isfinite(data).all():
        raise ValueError("Readings contain NaN or infinite values.")

    features = np.concatenate([
        np.mean(data, axis=0),
        np.std(data, axis=0),
        np.min(data, axis=0),
        np.max(data, axis=0)
    ]).reshape(1, -1)

    prediction = int(model.predict(features)[0])
    probabilities = model.predict_proba(features)[0]
    confidence = float(np.max(probabilities))

    return {
        "prediction": "Running" if prediction == 1 else "Walking",
        "class_id": prediction,
        "model_confidence": round(confidence, 4),
        "warning": "Activity estimate only; not an emergency detector."
    }
