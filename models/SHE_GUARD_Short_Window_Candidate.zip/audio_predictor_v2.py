
import os
import joblib
import librosa
import numpy as np

MODEL_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(
    MODEL_DIR, "she_guard_short_window_candidate.joblib"
)

model = joblib.load(MODEL_PATH)

SAMPLE_RATE = 22050
WINDOW_SECONDS = 0.5
HOP_SECONDS = 0.25
THRESHOLD = 0.60

def predict_audio(file_path):
    audio, _ = librosa.load(
        file_path, sr=SAMPLE_RATE, mono=True
    )

    if len(audio) == 0:
        return {
            "prediction": "no_audio",
            "scream_score": 0.0,
            "windows_checked": 0
        }

    window_size = int(WINDOW_SECONDS * SAMPLE_RATE)
    hop_size = int(HOP_SECONDS * SAMPLE_RATE)
    probabilities = []

    for start in range(0, len(audio), hop_size):
        segment = audio[start:start + window_size]

        if len(segment) == 0:
            continue

        if len(segment) < window_size:
            segment = np.pad(
                segment, (0, window_size - len(segment))
            )

        mfcc = librosa.feature.mfcc(
            y=segment,
            sr=SAMPLE_RATE,
            n_mfcc=13
        )

        features = np.concatenate([
            np.mean(mfcc, axis=1),
            np.std(mfcc, axis=1)
        ]).reshape(1, -1)

        scream_index = list(model.classes_).index("scream")
        score = float(model.predict_proba(features)[0][scream_index])
        probabilities.append(score)

    max_score = max(probabilities, default=0.0)

    return {
        "prediction": (
            "scream_candidate"
            if max_score >= THRESHOLD
            else "not_scream"
        ),
        "scream_score": round(max_score, 4),
        "windows_checked": len(probabilities)
    }
