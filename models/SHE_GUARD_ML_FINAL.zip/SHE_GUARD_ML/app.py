
import os
import sys
import requests
import gradio as gr
import folium

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from predictor import predict_historical_tier
from route_engine import analyze_routes


def find_place(name):
    response = requests.get(
        "https://nominatim.openstreetmap.org/search",
        params={"q": name, "format": "jsonv2", "limit": 1},
        headers={"User-Agent": "SHE-GUARD-Prototype/1.0"},
        timeout=20
    )
    response.raise_for_status()
    matches = response.json()

    if not matches:
        raise gr.Error(f"Location not found: {name}")

    p = matches[0]
    return float(p["lat"]), float(p["lon"]), p["display_name"]


def check_route(start_name, destination_name, month):
    if not start_name or not destination_name:
        raise gr.Error("Please enter both locations.")

    try:
        lat1, lon1, start_label = find_place(start_name)
        lat2, lon2, end_label = find_place(destination_name)

        # Check the starting area first
        origin = predict_historical_tier(lat1, lon1, int(month))

        tier = origin.get("historical_tier")

        if tier == "HIGHER HISTORICAL COUNT":
            gr.Warning(
                "This area has a higher historical crime-report count. "
                "This is not a live crime alert.",
                title="Historical hotspot warning"
            )
            alert = (
                "## ⚠️ Historical hotspot warning\\n"
                "This area falls in the higher historical-count category. "
                "This does not mean a crime is happening now."
            )

        elif tier == "MIDDLE HISTORICAL COUNT":
            alert = (
                "## ℹ️ Middle historical-count category\\n"
                "The model places this area in the middle category. "
                "This is not a live danger assessment."
            )

        elif tier == "LOWER HISTORICAL COUNT":
            alert = (
                "## ℹ️ Lower historical-count category\\n"
                "Fewer reports were recorded in the available historical "
                "data for this grid cell. This does not guarantee safety."
            )

        else:
            gr.Warning(
                "Historical information is unavailable for this area.",
                title="Insufficient historical data"
            )
            alert = (
                "## ⚪ Area information unavailable\\n"
                "We couldn't reliably assess this starting area."
            )

        result = analyze_routes(
            start=(lat1, lon1),
            destination=(lat2, lon2),
            month=int(month),
            alternatives="true"
        )

        routes = result["routes"]
        # Compare the share of sampled points with higher historical counts.
        eligible = [r for r in routes if r["coverage_percent"] >= 70]

        recommendation = None
        if eligible:
            recommendation = min(
                eligible,
                key=lambda r: (
                    r["higher_historical_count_points"] /
                    max(r["sampled_points"], 1),
                    r["duration_minutes"]
                )
            )

        m = folium.Map(location=[lat1, lon1], zoom_start=12)
        folium.Marker(
            [lat1, lon1], tooltip="Starting point",
            icon=folium.Icon(color="blue")
        ).add_to(m)
        folium.Marker(
            [lat2, lon2], tooltip="Destination",
            icon=folium.Icon(color="red")
        ).add_to(m)

        lines = [
            "# 🛡️ SHE-GUARD",
            f"**From:** {start_label}",
            f"**To:** {end_label}",
            "",
            alert,
            "",
            "## Alternative routes"
        ]

        for i, r in enumerate(routes):
            is_recommended = (
                recommendation is not None
                and r["route_number"] == recommendation["route_number"]
            )

            color = "green" if is_recommended else ["blue", "purple", "orange"][i % 3]
            points = [
                [lat, lon]
                for lon, lat in r["geometry"]["coordinates"]
            ]
            folium.PolyLine(
                points, color=color, weight=5,
                tooltip=f"Route {r['route_number']}"
            ).add_to(m)

            fraction = (
                r["higher_historical_count_points"] /
                max(r["sampled_points"], 1)
            ) * 100

            title = "⭐ Suggested alternative" if is_recommended else "Route option"
            lines.extend([
                f"### {title} — Route {r['route_number']}",
                f"- Distance: {r['distance_km']} km",
                f"- Travel time estimate: {r['duration_minutes']} minutes",
                f"- Historical data available for {r['coverage_percent']}% "
                "of sampled points",
                f"- Sampled points in the higher-count category: "
                f"{fraction:.0f}%",
                ""
            ])

        if recommendation is None:
            lines.extend([
                "## No route suggestion yet",
                "We don't have enough historical data coverage to suggest "
                "one route over another. Review the available options."
            ])
        else:
            lines.extend([
                "## Why this route?",
                "It had a lower share of sampled points in the higher-count "
                "historical category among routes with sufficient data. "
                "This is not proof that it is safer."
            ])

        lines.append(
            "**Please remember:** These are historical reports, not live "
            "crime alerts. Conditions may change, and missing data does not "
            "mean an area is safe."
        )

        return "\n".join(lines), m._repr_html_()

    except gr.Error:
        raise
    except Exception as e:
        raise gr.Error(
            f"Couldn't complete the route check. Please try again. ({e})"
        )


with gr.Blocks(title="SHE-GUARD Safety Assistant") as demo:
    gr.Markdown(
        "# 🛡️ SHE-GUARD\n"
        "### Check your route before you travel"
    )
    start = gr.Textbox(
        label="Where are you starting?",
        placeholder="e.g. MG Road, Bengaluru"
    )
    destination = gr.Textbox(
        label="Where do you want to go?",
        placeholder="e.g. Bengaluru Railway Station"
    )
    month = gr.Dropdown(
        choices=[1, 2, 3],
        value=1,
        label="Month to check",
        info="Historical model data currently covers January–March only."
    )
    button = gr.Button("Check area & find alternative", variant="primary")
    report = gr.Markdown()
    map_view = gr.HTML()

    button.click(
        check_route,
        inputs=[start, destination, month],
        outputs=[report, map_view]
    )

demo.launch(share=True)
