
import requests
import sys
import os
import math

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from predictor import predict_historical_tier

OSRM_URL = "https://router.project-osrm.org/route/v1/driving"

def analyze_routes(start, destination, month=1, alternatives=2):
    """
    start/destination: (latitude, longitude)
    Returns actual road-route alternatives and historical indicators.
    """

    for name, point in [("start", start), ("destination", destination)]:
        if len(point) != 2:
            raise ValueError(f"{name} must be (latitude, longitude)")
        lat, lon = map(float, point)
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise ValueError(f"Invalid coordinates for {name}")

    if not 1 <= int(month) <= 12:
        raise ValueError("Month must be between 1 and 12")

    # OSRM expects longitude,latitude
    coordinates = (
        f"{start[1]},{start[0]};"
        f"{destination[1]},{destination[0]}"
    )

    response = requests.get(
        f"{OSRM_URL}/{coordinates}",
        params={
            "alternatives": str(alternatives).lower(),
            "overview": "full",
            "geometries": "geojson",
            "steps": "false"
        },
        timeout=30
    )
    response.raise_for_status()
    data = response.json()

    if data.get("code") != "Ok" or not data.get("routes"):
        raise RuntimeError(f"Routing service error: {data.get('code')}")

    results = []

    for route_number, route in enumerate(data["routes"], start=1):
        coords = route["geometry"]["coordinates"]  # [lon, lat]

        # Sample route points, including endpoints, to keep analysis manageable
        sample_count = min(30, len(coords))
        if sample_count == 1:
            indices = [0]
        else:
            indices = sorted(set(
                round(i * (len(coords) - 1) / (sample_count - 1))
                for i in range(sample_count)
            ))

        samples = []
        for idx in indices:
            lon, lat = coords[idx]
            prediction = predict_historical_tier(
                latitude=lat,
                longitude=lon,
                month=int(month)
            )
            samples.append(prediction)

        covered = [
            p for p in samples
            if p["status"] == "HISTORICAL_INDICATOR_ONLY"
        ]
        higher = sum(
            p.get("historical_tier") == "HIGHER HISTORICAL COUNT"
            for p in covered
        )

        results.append({
            "route_number": route_number,
            "distance_km": round(route["distance"] / 1000, 2),
            "duration_minutes": round(route["duration"] / 60, 1),
            "sampled_points": len(samples),
            "covered_points": len(covered),
            "coverage_percent": round(
                100 * len(covered) / len(samples), 1
            ) if samples else 0,
            "higher_historical_count_points": higher,
            "historical_indicator": (
                "LIMITED DATA"
                if len(covered) < max(1, math.ceil(0.7 * len(samples)))
                else "COMPARISON AVAILABLE"
            ),
            "geometry": route["geometry"],
            "sample_results": samples
        })

    # Sort only by available coverage and historical indicators.
    # Do not call this a safety ranking.
    results.sort(key=lambda r: (
        r["coverage_percent"] < 70,
        r["higher_historical_count_points"],
        r["duration_minutes"]
    ))

    return {
        "status": "ROUTE_COMPARISON_ONLY",
        "month_analyzed": int(month),
        "routes_found": len(results),
        "routes": results,
        "warning": (
            "Historical FIR indicators do not establish current danger "
            "or guarantee route safety. Sampled points are not every "
            "road segment; this is an experimental comparison."
        )
    }
