SHE-GUARD - HISTORICAL HOTSPOT MODEL

Required files:
- she_guard_hotspot_model.joblib
- model_metadata.json
- predictor.py
- grid_support.csv
- route_engine.py
- app.py

Setup:
1. Install Python and dependencies from requirements.txt.
2. Keep all model files together in one folder.
3. Run smoke tests before deployment.
4. Run app.py to launch the Gradio prototype.

Limitations:
- Current model supports January, February and March only.
- Predictions represent historical FIR-count categories, not live crime.
- Lower historical count does not guarantee safety.
- Geocoding and route alternatives require internet access.
