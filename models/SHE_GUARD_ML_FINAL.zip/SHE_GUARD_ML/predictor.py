
import os
import joblib
import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL = joblib.load(
    os.path.join(BASE_DIR, "she_guard_hotspot_model.joblib")
)

SUPPORT_PATH = os.path.join(BASE_DIR, "grid_support.csv")
support_df = pd.read_csv(SUPPORT_PATH)

SUPPORT = {
    (round(float(row.grid_lat), 2),
     round(float(row.grid_lon), 2)): int(row.historical_records)
    for row in support_df.itertuples(index=False)
}

FEATURES = ["grid_lat", "grid_lon", "FIR_MONTH"]
MIN_RECORDS = 5

def predict_historical_tier(latitude, longitude, month):
    latitude = float(latitude)
    longitude = float(longitude)
    month = int(month)

    if not -90 <= latitude <= 90:
        raise ValueError("Invalid latitude")
    if not -180 <= longitude <= 180:
        raise ValueError("Invalid longitude")
    if not 1 <= month <= 12:
        raise ValueError("Month must be between 1 and 12")

    grid_lat = round(latitude, 2)
    grid_lon = round(longitude, 2)
    key = (grid_lat, grid_lon)
    records = SUPPORT.get(key, 0)

    base = {
        "grid_cell": key,
        "month": month,
        "historical_records": records,
        "status": "HISTORICAL_INDICATOR_ONLY",
        "warning": (
            "Historical FIR data is not a live crime alert "
            "or a guarantee of personal safety."
        )
    }

    if records < MIN_RECORDS:
        base["status"] = "INSUFFICIENT_HISTORICAL_DATA"
        base["historical_tier"] = None
        base["message"] = (
            "Insufficient records in this grid cell; "
            "no tier prediction returned."
        )
        return base

    # The training data covered January–March only.
    if month not in [1, 2, 3]:
        base["status"] = "MONTH_OUTSIDE_TRAINING_COVERAGE"
        base["historical_tier"] = None
        base["message"] = (
            "This model was trained on January–March data only. "
            "No prediction returned for this month."
        )
        return base

    X = pd.DataFrame([{
        "grid_lat": grid_lat,
        "grid_lon": grid_lon,
        "FIR_MONTH": month
    }], columns=FEATURES)

    prediction = int(MODEL.predict(X)[0])

    tiers = {
        0: "LOWER HISTORICAL COUNT",
        1: "MIDDLE HISTORICAL COUNT",
        2: "HIGHER HISTORICAL COUNT"
    }

    base["historical_tier"] = tiers.get(prediction, "UNKNOWN")
    return base
